"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Trash, Clock } from "lucide-react"
import { HistoryItem } from "@/types"

interface HistoryListProps {
  items: HistoryItem[]
  onClear: () => void
  onRemove: (id: string) => void
}

export function HistoryList({ items, onClear, onRemove }: HistoryListProps) {
  if (!items.length) return null

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Clock className="h-4 w-4" /> Download history
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={onClear} className="text-muted-foreground">
          Clear all
        </Button>
      </CardHeader>
      <CardContent className="space-y-2">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-3 rounded-lg border p-2.5 hover:bg-accent/50 transition-colors"
          >
            {item.thumbnail ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={item.thumbnail}
                alt=""
                className="h-12 w-20 rounded object-cover shrink-0"
              />
            ) : (
              <div className="h-12 w-20 rounded bg-muted shrink-0" />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium truncate">{item.title}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                  {item.platform}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {item.quality} · {new Date(item.downloadedAt).toLocaleString()}
                </span>
              </div>
            </div>
            <Button variant="outline" size="icon" asChild title="Download again">
              <a href={`/api/file/${item.fileId}`}>
                <Download className="h-4 w-4" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onRemove(item.id)}
              title="Remove from history"
            >
              <Trash className="h-4 w-4 text-muted-foreground" />
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
