"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Settings, ChevronDown, ChevronUp, Check, Trash, Loader2 } from "lucide-react"

export function CookieSettings() {
  const [open, setOpen] = useState(false)
  const [configured, setConfigured] = useState(false)
  const [content, setContent] = useState("")
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)

  useEffect(() => {
    fetch("/api/cookies")
      .then((r) => r.json())
      .then((d) => setConfigured(Boolean(d.configured)))
      .catch(() => {})
  }, [])

  const save = async () => {
    setSaving(true)
    setMessage(null)
    try {
      const res = await fetch("/api/cookies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? "Failed to save")
      setConfigured(true)
      setContent("")
      setMessage({ ok: true, text: "Cookies saved — YouTube and login-gated videos should now work." })
    } catch (e: unknown) {
      setMessage({ ok: false, text: e instanceof Error ? e.message : "Failed to save cookies" })
    } finally {
      setSaving(false)
    }
  }

  const clear = async () => {
    await fetch("/api/cookies", { method: "DELETE" })
    setConfigured(false)
    setMessage({ ok: true, text: "Cookies removed." })
  }

  return (
    <Card>
      <CardHeader
        className="flex flex-row items-center justify-between space-y-0 py-4 cursor-pointer select-none"
        onClick={() => setOpen(!open)}
      >
        <CardTitle className="text-base flex items-center gap-2">
          <Settings className="h-4 w-4" /> Settings — cookies for login-gated sites
          {configured && (
            <Badge variant="secondary" className="gap-1">
              <Check className="h-3 w-3" /> Active
            </Badge>
          )}
        </CardTitle>
        {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </CardHeader>
      {open && (
        <CardContent className="space-y-3 pt-0">
          <p className="text-sm text-muted-foreground">
            Some platforms (especially YouTube) block downloads from server IPs unless you provide
            cookies from a logged-in browser. Export cookies with a browser extension like{" "}
            <span className="font-medium">&quot;Get cookies.txt LOCALLY&quot;</span> (Netscape
            format) and paste the file contents below. Cookies stay on this server only.
          </p>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={"# Netscape HTTP Cookie File\n.youtube.com\tTRUE\t/\tTRUE\t…"}
            className="font-mono text-xs min-h-32"
          />
          <div className="flex gap-2">
            <Button onClick={save} disabled={saving || !content.trim()} size="sm" className="gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Save cookies
            </Button>
            {configured && (
              <Button onClick={clear} variant="outline" size="sm" className="gap-2">
                <Trash className="h-4 w-4" /> Remove cookies
              </Button>
            )}
          </div>
          {message && (
            <p className={`text-sm ${message.ok ? "text-green-600 dark:text-green-400" : "text-destructive"}`}>
              {message.text}
            </p>
          )}
        </CardContent>
      )}
    </Card>
  )
}
