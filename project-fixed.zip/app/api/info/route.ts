import { NextRequest, NextResponse } from "next/server"
import {
  execFileAsync,
  isValidUrl,
  detectPlatform,
  QUALITY_MAP,
  cookieArgs,
  friendlyError,
} from "@/lib/ytdlp"
import { cookiesPathForSession, SESSION_COOKIE } from "@/lib/session"
import { VideoInfo } from "@/types"

export const maxDuration = 120

export async function POST(request: NextRequest) {
  const sessionId = request.cookies.get(SESSION_COOKIE)?.value
  const cookiesPath = sessionId ? cookiesPathForSession(sessionId) : null
  let url = ""
  try {
    const body = await request.json()
    url = String(body?.url ?? "").trim()
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }

  if (!isValidUrl(url)) {
    return NextResponse.json({ error: "Please enter a valid http(s) URL" }, { status: 400 })
  }

  try {
    const { stdout } = await execFileAsync(
      "yt-dlp",
      ["-J", "--no-playlist", "--no-warnings", ...cookieArgs(cookiesPath), url],
      { maxBuffer: 64 * 1024 * 1024, timeout: 90_000 }
    )
    const raw = JSON.parse(stdout)
    const entry = raw?._type === "playlist" ? raw.entries?.[0] : raw
    if (!entry) throw new Error("No video found at this URL")

    // Determine the max available height to filter resolution options
    const heights: number[] = Array.isArray(entry.formats)
      ? entry.formats
          .map((f: { height?: number | null }) => f.height ?? 0)
          .filter((h: number) => h > 0)
      : []
    const maxHeight = heights.length ? Math.max(...heights) : 0

    const formats = Object.entries(QUALITY_MAP)
      .filter(([key]) => {
        if (key === "best" || key === "audio") return true
        if (maxHeight === 0) return true // unknown — offer everything
        return parseInt(key) <= maxHeight
      })
      .map(([value, v]) => ({ value, label: v.label }))

    const info: VideoInfo = {
      id: entry.id ?? crypto.randomUUID(),
      title: entry.title ?? "Untitled video",
      thumbnail: entry.thumbnail ?? null,
      duration: typeof entry.duration === "number" ? entry.duration : null,
      uploader: entry.uploader ?? entry.channel ?? null,
      platform: detectPlatform(url),
      webpageUrl: entry.webpage_url ?? url,
      formats,
    }
    return NextResponse.json(info)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Failed to fetch video info"
    return NextResponse.json({ error: friendlyError(msg), detail: msg.slice(0, 500) }, { status: 422 })
  }
}
