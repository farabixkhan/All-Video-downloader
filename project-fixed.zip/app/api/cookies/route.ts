import { NextRequest, NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"
import { getOrCreateSessionId, cookiesPathForSession, SESSION_COOKIE } from "@/lib/session"

function attachSessionCookie(res: NextResponse, sessionId: string) {
  res.cookies.set(SESSION_COOKIE, sessionId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30, // 30 days
  })
}

export async function GET(request: NextRequest) {
  const { sessionId, isNew } = getOrCreateSessionId(request.cookies.get(SESSION_COOKIE)?.value)
  const cookiesPath = cookiesPathForSession(sessionId)
  let payload: { configured: boolean; updatedAt?: string }
  try {
    const st = await fs.stat(cookiesPath)
    payload = { configured: true, updatedAt: st.mtime.toISOString() }
  } catch {
    payload = { configured: false }
  }
  const res = NextResponse.json(payload)
  if (isNew) attachSessionCookie(res, sessionId)
  return res
}

export async function POST(request: NextRequest) {
  const { sessionId } = getOrCreateSessionId(request.cookies.get(SESSION_COOKIE)?.value)
  let content = ""
  try {
    const body = await request.json()
    content = String(body?.content ?? "")
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }
  const trimmed = content.trim()
  if (!trimmed || trimmed.length > 1_000_000) {
    return NextResponse.json({ error: "Cookie file is empty or too large" }, { status: 400 })
  }
  // Netscape cookie files have tab-separated lines; be lenient but sanity-check
  if (!trimmed.split("\n").some((l) => l.includes("\t") || l.startsWith("# Netscape"))) {
    return NextResponse.json(
      { error: "That doesn't look like a Netscape-format cookies.txt export" },
      { status: 400 }
    )
  }
  const header = trimmed.startsWith("# Netscape") ? "" : "# Netscape HTTP Cookie File\n"
  const cookiesPath = cookiesPathForSession(sessionId)
  await fs.mkdir(path.dirname(cookiesPath), { recursive: true })
  await fs.writeFile(cookiesPath, header + trimmed + "\n", { mode: 0o600 })
  const res = NextResponse.json({ configured: true })
  attachSessionCookie(res, sessionId)
  return res
}

export async function DELETE(request: NextRequest) {
  const { sessionId } = getOrCreateSessionId(request.cookies.get(SESSION_COOKIE)?.value)
  const cookiesPath = cookiesPathForSession(sessionId)
  await fs.rm(cookiesPath, { force: true }).catch(() => {})
  const res = NextResponse.json({ configured: false })
  attachSessionCookie(res, sessionId)
  return res
}
