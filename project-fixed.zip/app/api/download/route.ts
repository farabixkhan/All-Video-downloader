import { NextRequest, NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"
import {
  execFileAsync,
  isValidUrl,
  QUALITY_MAP,
  DOWNLOAD_ROOT,
  cookieArgs,
  friendlyError,
} from "@/lib/ytdlp"
import { cookiesPathForSession, SESSION_COOKIE } from "@/lib/session"
import { DownloadResult } from "@/types"

export const maxDuration = 300

export async function POST(request: NextRequest) {
  const sessionId = request.cookies.get(SESSION_COOKIE)?.value
  const cookiesPath = sessionId ? cookiesPathForSession(sessionId) : null
  let url = ""
  let quality = "best"
  try {
    const body = await request.json()
    url = String(body?.url ?? "").trim()
    quality = String(body?.quality ?? "best")
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }

  if (!isValidUrl(url)) {
    return NextResponse.json({ error: "Please enter a valid http(s) URL" }, { status: 400 })
  }
  const q = QUALITY_MAP[quality] ?? QUALITY_MAP.best

  const fileId = crypto.randomUUID()
  const dir = path.join(DOWNLOAD_ROOT, fileId)
  await fs.mkdir(dir, { recursive: true })

  try {
    await execFileAsync(
      "yt-dlp",
      [
        ...q.args,
        ...cookieArgs(cookiesPath),
        "--no-playlist",
        "--no-warnings",
        "--restrict-filenames",
        "-o",
        path.join(dir, "%(title).80s.%(ext)s"),
        url,
      ],
      { maxBuffer: 16 * 1024 * 1024, timeout: 280_000 }
    )

    const files = await fs.readdir(dir)
    if (!files.length) throw new Error("Download produced no file")
    // Pick the largest file (the merged output)
    let best = files[0]
    let bestSize = 0
    for (const f of files) {
      const st = await fs.stat(path.join(dir, f))
      if (st.size > bestSize) {
        bestSize = st.size
        best = f
      }
    }

    const result: DownloadResult = { fileId, filename: best, sizeBytes: bestSize }
    return NextResponse.json(result)
  } catch (err: unknown) {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {})
    const msg = err instanceof Error ? err.message : "Download failed"
    return NextResponse.json({ error: friendlyError(msg), detail: msg.slice(0, 500) }, { status: 422 })
  }
}
