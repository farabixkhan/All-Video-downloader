import { execFile } from "child_process"
import { promisify } from "util"
import { existsSync } from "fs"
import path from "path"

export const execFileAsync = promisify(execFile)

/**
 * Resolve the project root regardless of the working directory the server
 * was launched from. The dev server is sometimes restarted with cwd set to
 * the home directory, which used to break download/file paths (404s).
 */
function findProjectRoot(): string {
  const candidates = [
    process.cwd(),
    path.join(process.cwd(), "magica", "projects", "app"),
    "/home/user/magica/projects/app",
  ]
  for (const c of candidates) {
    if (existsSync(path.join(c, "next.config.js")) || existsSync(path.join(c, "next.config.ts"))) {
      return c
    }
  }
  return process.cwd()
}

export const PROJECT_ROOT = findProjectRoot()
export const DOWNLOAD_ROOT = path.join(PROJECT_ROOT, "downloads")

// Cookies are now stored per-session (see lib/session.ts) instead of one
// shared file, so one visitor's login session is never used for another
// visitor's downloads.
export function cookieArgs(cookiesPath: string | null | undefined): string[] {
  return cookiesPath && existsSync(cookiesPath) ? ["--cookies", cookiesPath] : []
}

export function isValidUrl(input: string): boolean {
  try {
    const u = new URL(input)
    return u.protocol === "http:" || u.protocol === "https:"
  } catch {
    return false
  }
}

export function detectPlatform(url: string): string {
  const host = (() => {
    try {
      return new URL(url).hostname.replace(/^www\./, "")
    } catch {
      return ""
    }
  })()
  if (/youtube\.com|youtu\.be/.test(host)) return "YouTube"
  if (/tiktok\.com/.test(host)) return "TikTok"
  if (/instagram\.com/.test(host)) return "Instagram"
  if (/twitter\.com|x\.com/.test(host)) return "X / Twitter"
  if (/facebook\.com|fb\.watch/.test(host)) return "Facebook"
  if (/linkedin\.com/.test(host)) return "LinkedIn"
  if (/vimeo\.com/.test(host)) return "Vimeo"
  if (/reddit\.com/.test(host)) return "Reddit"
  if (/twitch\.tv/.test(host)) return "Twitch"
  if (/dailymotion\.com/.test(host)) return "Dailymotion"
  return host || "Unknown"
}

export function friendlyError(msg: string): string {
  if (msg.includes("Sign in to confirm"))
    return "This platform is asking for login verification from the server. Paste your browser cookies in Settings (bottom of the page) to unlock it."
  if (msg.includes("Requested format is not available"))
    return "That quality isn't available for this video — try 'Best available'."
  if (msg.includes("Unsupported URL"))
    return "This URL isn't supported. Try a direct video post link."
  if (msg.includes("Private") || msg.includes("login required"))
    return "This video is private or requires login — adding cookies in Settings may help."
  if (msg.includes("timeout") || msg.includes("ETIMEDOUT"))
    return "The request timed out — the video may be very long. Try a lower quality."
  return "Request failed. The video may be private, region-locked, or unsupported."
}

// Map friendly quality keys to yt-dlp format selectors
export const QUALITY_MAP: Record<string, { args: string[]; label: string }> = {
  best: {
    label: "Best available (video + audio)",
    args: ["-f", "bv*+ba/b", "--merge-output-format", "mp4"],
  },
  "2160p": {
    label: "4K (2160p)",
    args: ["-f", "bv*[height<=2160]+ba/b[height<=2160]", "--merge-output-format", "mp4"],
  },
  "1080p": {
    label: "Full HD (1080p)",
    args: ["-f", "bv*[height<=1080]+ba/b[height<=1080]", "--merge-output-format", "mp4"],
  },
  "720p": {
    label: "HD (720p)",
    args: ["-f", "bv*[height<=720]+ba/b[height<=720]", "--merge-output-format", "mp4"],
  },
  "480p": {
    label: "SD (480p)",
    args: ["-f", "bv*[height<=480]+ba/b[height<=480]", "--merge-output-format", "mp4"],
  },
  audio: {
    label: "Audio only (MP3)",
    args: ["-x", "--audio-format", "mp3", "--audio-quality", "0"],
  },
}
