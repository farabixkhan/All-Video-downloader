import { randomUUID } from "crypto"
import path from "path"
import { PROJECT_ROOT } from "./ytdlp"

export const SESSION_COOKIE = "vdl_session"

/**
 * Every browser gets its own session id (stored in an httpOnly cookie) so
 * that pasted YouTube/etc. cookies are never shared between visitors of
 * the same running instance.
 */
export function getOrCreateSessionId(cookieValue: string | undefined): {
  sessionId: string
  isNew: boolean
} {
  if (cookieValue && /^[0-9a-f-]{36}$/i.test(cookieValue)) {
    return { sessionId: cookieValue, isNew: false }
  }
  return { sessionId: randomUUID(), isNew: true }
}

export function cookiesPathForSession(sessionId: string): string {
  return path.join(PROJECT_ROOT, ".data", "sessions", sessionId, "cookies.txt")
}
